const form = document.getElementById('form');
const name = document.getElementById('name');
const contact = document.getElementById('contact');
const company = document.getElementById('company');
const service = document.getElementById('service');
const email = document.getElementById('email');


form.addEventListener('submit', e => {
    e.preventDefault();
    validateInputs();
});

//Clears text fields of the initial value when the user clicks on them
form.addEventListener('click', e => {
    e.preventDefault();
    clearText();
});


const setError = (element, message) => {
    const inputcontrol = element.parentElement;
    const errorDisplay = inputcontrol.querySelector('.error'); 

    errorDisplay.innerText = message;
    inputcontrol.classList.add('error');
    inputcontrol.classList.remove('success');

};

const setSuccess = (element) => {
    const inputcontrol = element.parentElement;
    inputcontrol.classList.remove('error');
    inputcontrol.classList.add('success');
};

const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email).toLowerCase();
};

const validateInputs = () => {
    const name = name.value.trim();
    const contact = contact.value.trim();
    const company = company.value.trim();
    const service = service.value.trim();
    const email = email.value.trim();
    
    if (name === '') {
        setErrorFor(name, 'A name is required for future correspondence');
    } else {
        setSuccessFor(name);
    }

     if (contact === '') {
        setErrorFor(contact, 'please enter a valid contact number');
    } else {
        setSuccessFor(contact);
    }

     if (company === '') {
        setErrorFor(comapny, 'please enter company name');
    } else {
        setSuccessFor(company);
    }

     if (service === '') {
        setErrorFor(services, 'please enter the service you are interested in');
    } else {
        setSuccessFor(service);
    }

    if (email === '') {
        setErrorFor(email, 'please enter email address');
    }
      else if (!isValidEmail(email)) {
        setErrorFor(email, 'please enter a valid email address');
    } else {
      setSuccessFor(email);
    }
    
};

function clearText(){
  var inputs = this.getElementsByTagName('input');
  // Clear the value of each input element
  for (var i = 0; i < inputs.length; i++) {
    inputs[i].value = '';
  }
};
