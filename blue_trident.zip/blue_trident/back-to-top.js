document.addEventListener('DOMContentLoaded', function() {
    let backToTop = document.getElementById('back-to-top');

    //show the button when the user scroll down 50px from the top of the document
    window.onscroll = function() {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            backToTop.style.display = 'block';
        }else{
            backToTop.style.display = 'none';
        }
    };

    //scroll to the top when button is pressed
    backToTop.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    });

});

