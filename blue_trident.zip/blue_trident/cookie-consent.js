function closeNotifications() {
    let cookieNote = document.getElementById("cookieNotification");
    cookieNote.style.display = "none";
}
document.getElementById("AcceptCookies").addEventListener("click", closeNotifications);